# Part-1-OOP-Programming---JAVA---Inheritance-Design-Lab-

Content of the Repository

This repository consists of five different java files that are connected using Inheritance.

File 1 - Hospital.java
File 2 - HospitalEmplopyee.java
File 3 - Doctor.java
File 4 - Nurse.java
File 5 - Surgeon.java


INSTRUCTIONS - 

How to Run the Part 1 - (OOP Programming - JAVA - Inheritance Design Lab)

Copy the downloaded files to the java bin location 

OR

Make bin path the permanent path by editing the Environmental Variables.

1st Step - Open command prompt in the location where youi have stored these files.

2nd Step - type "javac Hospital.java" and press enter.

3rd Step - type "java Hospital" and press enter.

Done.